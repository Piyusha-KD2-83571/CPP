

/*
Write a class Address with data members (string building, string street, string city ,int pin)
Implement constructors, getters, setters, accept(), and display() methods.
Test the class functunalities by creating the object of class and calling all the functions.
*/


#include <iostream>

using namespace std;



class address
{
private :
string building;
string street;
string city;
int pin;

public :

address()
{
    building = "Sunbeam";
    street   = "Shanivarpeth";
    city     = "Karad";
    pin      = 415110;



}


void setbuilding(string b)//setting building name
{
    building = b;
}
string getBuilding() // getting Building name
{
    return building;
}


void setStreet(string s) //setting street name
{
    street = s;

}
string getStreet() //getting Street Name
{
    return street;
}

void setCity(string c) //setting city name
{
    city = c;

}
string getCity() //getting city Name
{
    return city;

}

void setPin(int p) //setting pin
{
    pin = p;

}
int getPin() //getting Pin 
{
    return pin;
    
}


address(string building,string street,string city,int pin)
{
    this->building = building;
    this->street   = street;
    this->city     = city;
    this->pin      = pin;

}

void displayadd()
{
    cout<< "THE ADDRESS IS : \n";
    cout<< "Building :"<< building << endl;
    cout << "Street : "<< street << endl;
    cout << "City : "  << city << endl;
    cout << "Pin : "    << pin  << endl;
    cout<< "\n\n";

}


void acceptadd()
{
    cout << "ENTER ADDRESS : "<<endl;
    cout << "ENTER BUILDING NAME :"<< endl;
    cin  >> building;
    cout << "ENTER STREET NAME :"<< endl;
    cin  >> street;
    cout << "ENTER CITY NAME :"<< endl;
    cin  >> city;
    cout << "ENTER PIN NAME :"<< endl;
    cin  >> pin;
    cout << "\n";
}



};


int main()
{  //Parameterless Constructor
    address a1;
    a1.displayadd();



//Parameterized Constructor
   address a2("Rajmahal","Shahunagar","Kolhapur",415006);
   a2.displayadd();


//Accepting and Displaying
   address a4;
   a4.acceptadd();
   a4.displayadd();
    


//Getting Setting Values
    address a3;
    a3.setbuilding("Dwarka");
    cout<<"\nUSING GETTER SETTER METHOD: \n Building Name :"<<a3.getBuilding()<<endl;

    a3.setStreet("Rajpath");
    cout<< "Street Name : "<<a3.getStreet()<<endl;

    a3.setCity("Kanpur");
    cout<<"City Name :"<<a3.getCity()<<endl;

    a3.setPin(123456);
    cout<<"Pin : "<<a3.getPin()<<endl;


    return 0;
}