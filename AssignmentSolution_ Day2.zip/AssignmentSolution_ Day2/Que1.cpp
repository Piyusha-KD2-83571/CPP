/* Q1. Write a menu driven program to calculate volume of the box(length * width * height).
Provide parameterless, parameterized(with 3 parameters) and single paramaterized constructor.
Create the local objects in respective case and call the function to caluclate area.
Menu options ->
1. Calculate Volume with default values
2. Calculate Volume with length,breadth and height with same value
3. Calculate Volume with different length,breadth and height values.*/

#include <iostream>
using namespace std;

class volume
{ 
    private:
    int l;
    int w;
    int h;

    public:
     
     volume() ///Parameterless constructor
     {
         l = 3;
         w = 20;
         h = 10;
         cout << "Volume For Parameterless constructor : ";
         calVol();
         
     }

    volume (int v) //Single Parameterized constructor
    {
        l = v;
        w = v;
        h = v;
        cout << "Volume for single Parameterized Constructor :";
        calVol();
      
    }

    volume (int v1, int v2, int v3) //  Parameterized Constructor
    {
        l = v1;
        w = v2;
        h = v3;
        cout << "Volume For Different Parameters in constructor : ";
        calVol();
    }
  
   
    
    

    void calVol()
   { 
     
    cout << "VOLUME IS : " << l*w*h << endl;
   }

};


int main()
{

    
    volume v1;
    volume v2(5);
    volume v3(2,5,10);

    int choice;

    do 
    {
        cout<< "0.) Exit ";
        cout<< "1.) Volume with Default:\n";
        cout<< "2.) Volume with Same Values:\n ";
        cout<< "3.) Volume with Different Values:\n";
        cout<< "4.) Enter your Choice :  \n";
        cin >> choice;

        switch(choice)
        {
          case 0 : 
          cout << "Thank You For using our app : ";
          break;

          case 1 :
          cout << "VOLUME WITH DEFAULT VALUE \n";
          v1.calVol();
          break;

          case 2 :
          cout << "VOLUME WITH SAME VALUE  \n";
          v2.calVol();
          break;

          case 3 :
          cout << "VOLUME WITH DIFFERENT VALUE \n";
          v3.calVol();
          break;

          default : 
          cout << "ENTERED SOME WRONG CHOICE :-) ";
          break;



          
        }
        
        
    }
    while(choice != 0);

    return 0;
}