/*
Q1. Write a menu driven program for Date in a C. Declare a structure Date having data members
day, month, year. Implement the following functions.
void initDate(struct Date* ptrDate);
void printDateOnConsole(struct Date* ptrDate);
void acceptDateFromConsole(struct Date* ptrDate);
*/

#include<stdio.h> 

struct Date
{
    int dd;
    int mm;
    int yyyy;
};
    void initDate(struct Date* ptrDate)
    {
        ptrDate->dd = 01;
        ptrDate->mm = 01;
        ptrDate->yyyy = 2024;
    }

    void acceptDate(struct Date* ptrDate)
    {
        printf("Enter the date,month and year - ");
        scanf("%d%d%d",&ptrDate->dd,&ptrDate->mm,&ptrDate->yyyy);
    }

    void printDate(struct Date* ptrDate)
    {
        printf("Date: %d-%d-%d\n",ptrDate->dd,ptrDate->mm,ptrDate->yyyy);
    }

int main()
{
    struct Date d;
    initDate(&d);
    int choice;
    do{
        printf("0. Exit\n");
        printf("1. Accept Date\n");
        printf("2. Display Date\n");
        printf("Enter your choice\n -");
        scanf("%d",&choice);
        switch(choice)
        {
            case 0: 
            printf("Thank you for using thsi app..");
            break;
            case 1:
            acceptDate(&d);
            break;
            case 2:
            printDate(&d);
            break;
            default:
            printf("Incorrect Choice ! Please enter correct choice");

        }
    } while(choice !=0);
    return 0;    
}