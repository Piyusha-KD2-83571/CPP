/*Q1. Write a class to find volume of a Cylinder by using following members. (volume of
Cylinder=3.14 * radius * radius *height) ( use static wherever needed. hint-PI)
Class having following member functions:
Cylinder()
Cylinder(double radius, double height)
getRadius()
setRadius()
getHeight()
setHeight()
getVolume()
printVolume()
Initialize members using constructor member initializer list.*/

#include <iostream>
using namespace std;

class Cylinder
{
    private :
    double height;
    double radius;
    static const double PI;
    double Volume;

    public:

    Cylinder()
    {
        height = 5;
        radius = 5;
    }

    Cylinder (double radius,double height)
    {
        this->height = height;
        this->radius = radius;
    }



    void setRadius(double radius)
    {
      this->radius = radius;
    }

    double getRadius()
    {
        return radius;
    }

    void setHeight(double height)
    {
        this->height = height;
    }

    double getHeight()
    {
       return height;
    }

    

    void printVolume()
    {
       cout << "Volume of Cylinder : "<< PI * radius * radius*height << endl; 
    }

    double getVolume()
    {
        return Volume;
    }
    static double getPI()
    {
        return PI;
    }



};
const double Cylinder :: PI = 3.14; //Intialization of PI Value

int main()
{
    Cylinder c1;
    c1.printVolume();

    Cylinder c2(3.5,5);
    c2.printVolume();
    
    Cylinder c3;
    c3.setRadius(5);
    c3.getRadius();
    c3.setHeight(10.5);
    c3.getHeight();
    c3.printVolume();
    c3.getVolume();
    


    return 0;
}